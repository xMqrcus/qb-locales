local Translations = {
   error = {
       fingerprints = 'Du har sat fingeraftryk på glasset',
       minimum_police = 'Minimum på %{value} betjente skal være online',
       wrong_weapon = 'Dit våben er ikke stort nok..',
       to_much = 'Du har for meget i tasken'
   },
   success = {},
   info = {
       progressbar = 'Smadrer display-glasset',
   },
   general = {
       target_label = 'Ødelægger dispaly-glasset',
       drawtextui_grab = '[E] Ødelægger display-glasset',
       drawtextui_broken = "Display'et er ødelagt"
   }
}

Lang = Locale:new({phrases = Translations})
