local Translations = {
   error = {
       finish_work = "Færddiggør alt dit arbejde først",
       vehicle_not_correct = "Dette er ikke det rigtige køretøj",
       failed = "Du fejlede",
       not_towing_vehicle = "Du skal være i dit trækkøretøj ",
       too_far_away = "Du er for langt væk",
       no_work_done = "Intet arbejde gjort",
       no_deposit = "$%{value} Depositum påkrævet",
   },
   success = {
       paid_with_cash = "$%{value} Depositum betalt med kontanter",
       paid_with_bank = "$%{value} Depositum betalt med bankkonto",
       refund_to_cash = "$%{value} Depositum betalt med kontanter",
       you_earned = "You tjente $%{value}",
   },
   menu = {
       header = "Tilgængelige trucks",
       close_menu = "⬅ Luk menu",
   },
   mission = {
       delivered_vehicle = "Du har leveret et køretøj",
       get_new_vehicle = "Et nyt køretøj kan opsamles",
       towing_vehicle = "Hejser køretøjet...",
       goto_depot = "Tag køretøjet til depotet",
       vehicle_towed = "Køretøjet blev aflevert",
       untowing_vehicle = "Fjern køretøjet",
       vehicle_takenoff = "Køretøjet blev taget af",
   },
   info = {
       tow = "Placer en bil på bagsiden af din flatbed",
       toggle_npc = "Toggle NPC Job",
   }
}

Lang = Locale:new({
   phrases = Translations,
   warnOnMissing = true
})
