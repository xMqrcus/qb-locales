local Translations = {
   error = {
       no_people_nearby = "Ingen spillere i nærheden",
       no_vehicle_found = "Intet køretøj fundet",
       extra_deactivated = "Extra %{extra} er blevet deaktiveret",
       extra_not_present = "Extra %{extra} er ikke tilgængelig på dette køretøj",
       not_driver = "Du er ikke føreren af dette køretøj",
       vehicle_driving_fast = "Køretøjet kører for hurtigt",
       seat_occupied = "Dette sæde er optaget",
       race_harness_on = "Du har et racersæde på, du kan ikke skifte",
       obj_not_found = "Kunne ikke oprette det angivne objekt",
       not_near_ambulance = "Du er for langt væk fra en ambulance",
       far_away = "Du er for langt væk",
       stretcher_in_use = "Allerede i brug",
       not_kidnapped = "Du har ikke kidnappet denne person",
       trunk_closed = "Bagsmækken er lukket",
       cant_enter_trunk = "Du kan ikke hoppe ind i baggagerummet",
       already_in_trunk = "Du er allerede i baggagerummet",
       someone_in_trunk = "Der er allerede nogen i baggerummet"
   },
   success = {
       extra_activated = "Extra %{extra} er blevet aktiveret",
       entered_trunk = "Du gik ind i baggagerummet"
   },
   info = {
       no_variants = "Der er ikke nogle varianter af dette",
       wrong_ped = "PED Modellen tillader ikke dette",
       nothing_to_remove = "Du har intet at fjerne",
       already_wearing = "Du har allerede dette på",
       switched_seats = "Du sidder nu på %{seat} sæde"
   },
   general = {
       command_description = "Åbn hovedmenuen",
       push_stretcher_button = "~g~E~w~ - Skub båre",
       stop_pushing_stretcher_button = "~g~E~w~ - Stop med at skubbe",
       lay_stretcher_button = "~g~G~w~ - Lig på båre",
       push_position_drawtext = "Skub her",
       get_off_stretcher_button = "~g~G~w~ - Gå af båre",
       get_out_trunk_button = "[~g~E~w~] Gå ud af baggagerummet",
       close_trunk_button = "[~g~G~w~] Luk baggagerummet",
       open_trunk_button = "[~g~G~w~] Åbn baggagerummet",
       getintrunk_command_desc = "Gå ind i baggagerummet",
       putintrunk_command_desc = "Smid en spiller i baggagerummet"
   },
   options = {
       emergency_button = "Nødsknap",
       driver_seat = "Forsædet",
       passenger_seat = "Passagersædet",
       other_seats = "Andet sæde",
       rear_left_seat = "Venstre bagsæde",
       rear_right_seat = "Højre bagsæde"
   },
}

Lang = Locale:new({
   phrases = Translations,
   warnOnMissing = true
})