local Translations = {
   error = {
       not_your_vehicle = 'Dette er ikke dit køretøj',
       vehicle_does_not_exist = 'Køretøjet eksisterer ikke',
       not_enough_money = 'Du har ikke nok penge',
       finish_payments = 'Du skal være færdig med at betale køretøjet af, før du kan sælge den',
       no_space_on_lot = 'Der er ikke plads til dit køretøj på pladsen'
   },
   success = {
       sold_car_for_price = 'Du har solgt dit køretøj for $%{value}',
       car_up_for_sale = 'Dit køretøj er blevet sat til salg for $%{value}',
       vehicle_bought = 'Køretøj købt'
   },
   info = {
       confirm_cancel = '~g~Y~w~ - Bekræft / ~r~N~w~ - Afbryd ~g~',
       vehicle_returned = 'Dit køretøj er blevet returneret',
       used_vehicle_lot = 'Brugtvognsplads',
       sell_vehicle_to_dealer = '[~g~E~w~] - Sælg køretøj til dealer for ~g~$%{value}',
       view_contract = '[~g~E~w~] - Se købskontrakt',
       cancel_sale = '[~r~G~w~] - Afbryd salg',
       model_price = '%{value}, Pris: ~g~$%{value2}',
       are_you_sure = 'Er du sikker på du ikke længere vil sælge dit køretøj?',
       yes_no = '[~g~7~w~] - Ja | [~r~8~w~] - Nej',
       place_vehicle_for_sale = '[~g~E~w~] - Sæt køretøj til salg for ejer'
   },
   charinfo = {
       firstname = 'ikke',
       lastname = 'kendt',
       account = 'Ukendt konto nr.',
       phone = 'Ukendt telefon nr.'
   },
   mail = {
       sender = 'Larrys RV Sales',
       subject = 'Du har solgt et køretøj',
       message = 'Du tjente $%{value} fra salget af %{value2}.'
   }
}

Lang = Locale:new({
   phrases = Translations,
   warnOnMissing = true
})
