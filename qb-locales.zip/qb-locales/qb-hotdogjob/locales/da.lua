local Translations = {
   error = {
       no_money = 'Ikke nok penge',
       too_far = 'Du er for langt væk fra din hotdog-stand',
       no_stand = 'Du har ikke en hotdog-stand',
       cust_refused = 'Kunde afviste!',
       no_stand_found = 'Din hotdog-stand var ingen steder at se, du får ikke dit depositum tilbage!',
       no_more = 'Du har ikke %{value}',
       deposit_notreturned = 'Du havde ikke en hotdog-stand?',
   },
   success = {
       deposit = 'Du betalte et $%{deposit} depositum!',
       deposit_returned = 'Dit $%{deposit} depositum er blevet returneret!',
       sold_hotdogs = '%{value} x Hotdog(\'s) solgt for $%{value2}',
       made_hotdog = 'Du lavede %{value} hotdogs',
       made_luck_hotdog = 'Du lavede %{value} x %{value2} hotdogs',
   },
   info = {
       command = "Fjern stand (Admin Only)",
       blip_name = 'Hotdog Stand',
       start_working = '[E] Start arbejde',
       start_work = 'Start arbejde',
       stop_working = '[E] Stop arbejde',
       stop_work = 'Stop arbejde',
       grab_stall = '[~g~G~s~] Tag stand',
       drop_stall = '[~g~G~s~] Drop stand',
       grab = 'Tag stand',
       selling_prep = '[~g~E~s~] Hotdog prepare [Sale: ~g~Selling~w~]',
       not_selling = '[~g~E~s~] Hotdog prepare [Sale: ~r~Not Selling~w~]',
       sell_dogs = '[~g~7~s~] Sell %{value} x HotDogs for $%{value2} / [~g~8~s~] Reject',
       admin_removed = "Hot Dog Stand Removed",
       label_a = "Perfekt (A)",
       label_b = "Stælden (B)",
       label_c = "Normal (C)"
   }
}

Lang = Locale:new({
   phrases = Translations,
   warnOnMissing = true
})
