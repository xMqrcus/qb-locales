local Translations = {
   error = {
       negative = 'Prøver du at sælge et negativ antal?',
       no_melt = 'Du gav mig intet at smelte',
       no_items = 'Ikke nok ting',
   },
   success = {
       sold = 'Du har solgt %{value} x %{value2} for $%{value3}',
       items_received = 'Du modtog %{value} x %{value2}',
   },
   info = {
       title = 'Pawn Shop',
       subject = 'Melting Items',
       message = 'Vi blev færdige med at smelte dine ting. du kan samle dem op til hver en tid.',
       open_pawn = 'Åbn pawn shop',
       sell = 'Sælg ting',
       sell_pawn = 'Sælg ting til pawn shoppen',
       melt = 'Smelt ting',
       melt_pawn = 'Åbn smelte shopen',
       melt_pickup = 'Saml smeltede ting',
       pawn_closed = 'Pawnshoppen er lukket. Kom tilbage mellem %{value}:00 AM - %{value2}:00 PM',
       sell_items = 'Pris $%{value}',
       back = '⬅ Tilbage',
       melt_item = 'Smelt %{value}',
       max = 'Max antal %{value}',
       submit = 'Smelt',
       melt_wait = 'Giv mig %{value} minutter og jeg vil have dine ting klar',
   }
}

Lang = Locale:new({
   phrases = Translations,
   warnOnMissing = true
})