local Translations = {
   error = {
       not_enough = "Du har ikke nok kontanter..",
       no_slots = "Der er ingen pladser tilbage",
       occured = "Der opstod en fejl",
       have_keys = "Personen har allerede nøgler",
       p_have_keys = "%{value} Denne person har allerede nøgler",
       not_owner = "Du ejer ikke huset og har ikke nøgler",
       not_online = "Personen er ikke i byen",
       no_money = "Der er ingen penge på skabet",
       incorrect_code = "Koden er forkert",
       up_to_6 = "Du kan give op til 6 personer adgang",
       cancelled = "Opkøb adbrudt",
   },
   success = {
       added = "%{value} Er blevet tilføjet",
   },
   info = {
       enter = "Gå ind i traphouse",
       give_keys = "Giv nøgler til traphouse",
       pincode = "Traphouse Pinkode: %{value}",
       taking_over = "Tager over",
       pin_code_see = "~b~G~w~ - Se Pinkode",
       pin_code = "Pinkode: %{value}",
       multikeys = "~b~/multikeys~w~ [id] - For at give nøgler",
       take_cash = "~b~E~w~ - Tag penge (~g~$%{value}~w~)",
       inventory = "~b~H~w~ - Vis rygsæk",
       take_over = "~b~E~w~ - Tag over (~g~$5000~w~)",
       leave = "~b~E~w~ - Forlad traphoue",
   },
   targetInfo = {
       options = "Traphouse Options",
       enter = "Gå ind i traphouse",
       give_keys = "Giv nøgler til traphouse",
       pincode = "Traphouse Pinkode: %{value}",
       taking_over = "Tager over",
       pin_code_see = "~b~G~w~ - Se Pinkode",
       pin_code = "Pinkode: %{value}",
       multikeys = "~b~/multikeys~w~ [id] - For at give nøgler",
       take_cash = "~b~E~w~ - Tag penge (~g~$%{value}~w~)",
       inventory = "~b~H~w~ - Vis rygsæk",
       take_over = "~b~E~w~ - Tag over (~g~$5000~w~)",
       leave = "~b~E~w~ - Forlad traphoue",
       close_menu = "⬅ Forlad menu",
   }
}

   Lang = Locale:new({
       phrases = Translations,
       warnOnMissing = true
   })

