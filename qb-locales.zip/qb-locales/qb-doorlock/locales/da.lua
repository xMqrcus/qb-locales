local Translations = {
   error = {
       lockpick_fail = "Fejlede",
       door_not_found = "Modtog ikke dør-hash. Hvis døren er gennemsigtig, så kig på dørrammen",
       same_entity = "Begge døre kan ikke være det samme entity",
       door_registered = "Døren er allerede registreret",
       door_identifier_exists = "En dør med denne identifier eksisterer allerede i configgen. (%s)",
   },
   success = {
       lockpick_success = "Success"
   },
   general = {
       locked = "Låst",
       unlocked = "Ulåst",
       locked_button = "[E] - Låst",
       unlocked_button = "[E] - Ulåst",
       keymapping_description = "Interager med dørlåsene",
       keymapping_remotetriggerdoor = "Fjernstyr en dør",
       locked_menu = "Låst",
       pickable_menu = "Kan lockpickes",
       cantunlock_menu = 'Kan ikke åbne',
       hidelabel_menu = 'Skjul dør-label',
       distance_menu = "Max afstand",
       item_authorisation_menu = "Item Authorsation",
       citizenid_authorisation_menu = "CitizenID Authorisation",
       gang_authorisation_menu = "Gang Authorisation",
       job_authorisation_menu = "Job Authorisation",
       doortype_title = "Door Type",
       doortype_door = "Single Door",
       doortype_double = "Double Door",
       doortype_sliding = "Single Sliding Door",
       doortype_doublesliding = "Double Sliding Door",
       doortype_garage = "Garage",
       dooridentifier_title = "Unique Identifier",
       doorlabel_title = "Door Label",
       configfile_title = "Config File Name",
       submit_text = "Submit",
       newdoor_menu_title = "Add a new door",
       newdoor_command_description = "Add a new door to the doorlock system",
       doordebug_command_description = "Toggle debug mode",
       warning = "Warning",
       created_by = "created by",
       warn_no_permission_newdoor = "%{player} (%{license}) tried to add a new door without permission (source: %{source})",
       warn_no_authorisation = "%{player} (%{license}) attempted to open a door without authorisation (Sent: %{doorID})",
       warn_wrong_doorid = "%{player} (%{license}) attempted to update invalid door (Sent: %{doorID})",
       warn_wrong_state = "%{player} (%{license}) attempted to update to an invalid state (Sent: %{state})",
       warn_wrong_doorid_type = "%{player} (%{license}) didn't send an appropriate doorID (Sent: %{doorID})",
       warn_admin_privilege_used = "%{player} (%{license}) opened a door using admin privileges"
   }
}

Lang = Locale:new({
   phrases = Translations,
   warnOnMissing = true
})