local Translations = {
   success = {
       success_message = "Succes",
       fuses_are_blown = "Sikringerne er blevet sprunget",
       door_has_opened = "Døren har åbnet"
   },
   error = {
       cancel_message = "Afbrudt",
       safe_too_strong = "Det ser ud til at bank-døren er for stærk",
       missing_item = "Du mangler en ting",
       bank_already_open = "Banken er allerede åben",
       minimum_police_required = "Minimum på %{police} betjente online",
       security_lock_active = "Sikkerhedslåsen er aktiv, du kan ikke åbne døren",
       wrong_type = "KONTAKT UDVIKLER \n%{receiver} did not receive the right type for argument '%{argument}'\nreceived type: %{receivedType}\nreceived value: %{receivedValue}\n expected type: %{expected}",
       fuses_already_blown = "Sikringerne er allerede sprunger",
       event_trigger_wrong = "%{event}%{extraInfo} was triggered when some conditions weren't met, source: %{source}",
       missing_ignition_source = "Du mangler en ild-kilde"
   },
   general = {
       breaking_open_safe = "Åbner døren",
       connecting_hacking_device = "Tilslutter hacking-device",
       fleeca_robbery_alert = "Fleeca bank røveri-forsøg",
       paleto_robbery_alert = "Blain County Savings bank røveri-forsøg",
       pacific_robbery_alert = "Pacific Standard Bank røveri-forsøg",
       break_safe_open_option_target = "Bryd op",
       break_safe_open_option_drawtext = "[E] Break open",
       validating_bankcard = "Validerer kort..",
       thermite_detonating_in_seconds = "Thermite detonerer om %{time} second(s)",
       bank_robbery_police_call = "10-90: Bank Røveri"
   }
}

Lang = Locale:new({
   phrases = Translations,
   warnOnMissing = true
})
