local Translations = {
   error = {
       already_driving_bus = 'Du kører allerede en bus',
       not_in_bus = 'Du er ikke i en bus',
       one_bus_active = 'Du kan kun have en aktiv bus ad gangen',
       drop_off_passengers = 'Sæt passagererne af før du stopper arbejde'
   },
   success = {
       dropped_off = 'Personen blev droppet af',
   },
   info = {
       bus = 'Standard Bus',
       goto_busstop = 'Kør til busstoppet',
       busstop_text = '[E] Bus Stop',
       bus_plate = 'BUS', -- Can be 3 or 4 characters long (uses random 4 digits)
       bus_depot = 'Bus Depot',
       bus_stop_work = '[E] Stop arbejde',
       bus_job_vehicles = '[E] Job køretøjer'
   },
   menu = {
       bus_header = 'Bus køretøjer',
       bus_close = '⬅ Luk menu'
   }
}

Lang = Locale:new({
   phrases = Translations,
   warnOnMissing = true
})