local Translations = {
   error = {
       ["cancled"] = "Afbrudt",
       ["no_truck"] = "Du har ingen lastbil!",
       ["not_enough"] = "Du har ikke nok penge til depotet (%{value})",
       ["too_far"] = "Du er for langt fra drop-off punktet",
       ["early_finish"] = "På grund af tidlig afslutning af rute (Klaret: %{completed} Total: %{total}), vil dit depositum ikke blive returneret.",
       ["never_clocked_on"] = "Du mødte aldrig ind!",
   },
   success = {
       ["clear_routes"] = "Cleared users routes they had %{value} routes stored",
       ["pay_slip"] = "Du fik $%{total}, dit depositum på %{deposit} blev smidt ind på din konto!",
   },
   info = {
       ["payslip_collect"] = "[E] - Lønseddel",
       ["payslip"] = "Lønseddel",
       ["not_enough"] = "Du har ikke nok penge til depositum.. Pris: $%{value}",
       ["deposit_paid"] = "Du har betalt $%{value} i depositum!",
       ["no_deposit"] = "Du har ikke depoisitum på dette køretøj..",
       ["truck_returned"] = "Truck returneret!",
       ["bags_left"] = "Der er stadig %{value} skraldesække tilbage!",
       ["bags_still"] = "Der er stadig %{value} skraldesæk tilbage!",
       ["all_bags"] = "Alle skraldesække er taget, videre til næste lokation!",
       ["depot_issue"] = "Der var en fejl ved depositum!",
       ["done_working"] = "Du er færdig med arbejde! Tag tilbage til depotet.",
       ["started"] = "Du har startet arbejde, lokation markeret på GPS!",
       ["grab_garbage"] = "[E] Tag skraldesæk",
       ["stand_grab_garbage"] = "Stå her for at tage en skraldesæk.",
       ["dispose_garbage"] = "[E] Smid sæk ind",
       ["progressbar"] = "Smider sæk i skraldebil ..",
       ["garbage_in_truck"] = "Smid sæk ind..",
       ["stand_here"] = "Stå her..",
       ["found_crypto"] = "Du fandt en cryptostick på jorden",
       ["payout_deposit"] = "(+ $%{value} depositum)",
       ["store_truck"] =  "[E] - Opbevar skraldebil",
       ["get_truck"] =  "[E] - Skraldebil",
   },
   warning = {},
}
Lang = Locale:new({
   phrases = Translations,
   warnOnMissing = true
})
