local Translations = {
   error = {
       smash_own = "Du kan ikke smadre et køretøj du ejer",
       cannot_scrap = "Dette køretøj kan ikke blive scrapped",
       not_driver = "Du er ikke føreren",
       demolish_vehicle = "Du kan ikke gøre dette nu",
       canceled = "Afbrudt",
   },
   text = {
       scrapyard = 'Scrapyard',
       disassemble_vehicle = '~g~E~w~ - Adskil køretøj',
       email_list = "~g~E~w~ - E-mail bil-liste",
       demolish_vehicle = "Smadre køretøj",
   },
   email = {
       sender = "Turner’s Auto Wrecking",
     subject = "Bil-liste",
     message = "Du kan kun smadre nogle få køretøjer.<br />Du kan beholde alt hvad du får, bare du lader mig være.<br /><br /><strong>Bil-liste:</strong><br />",
   },
}

Lang = Locale:new({
   phrases = Translations,
   warnOnMissing = true
})