local Translations = {
   info = {
       search = 'Gennemsøg skraldespand',
   },
   error = {
       cooldown = 'Du kan ikke rode i skraldespanden før om %{time} sekunder',
       hasBeenSearched = "Skraldespanden er allerede søgt igennem!",
       nothingFound = "Du fandt intet!",
   },
   progressbar = {
       searching = "Gennemsøger skraldespand",
   },
   reward = {
       money = "Du fandt $%{amount}",
   }
}

Lang = Locale:new({
   phrases = Translations,
   warnOnMissing = true
})